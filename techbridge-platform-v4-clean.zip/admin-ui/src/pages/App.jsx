import React from 'react';

export default function App() {
  return <div><h1>TechBridge Admin UI</h1></div>;
}