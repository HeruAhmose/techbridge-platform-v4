# TechBridge Platform v4 - Setup Script for Windows PowerShell
# Automates local development startup for Flask API and React Admin UI

Write-Host "`n=== Setting up Flask API ===`n"
cd "api"
python -m venv venv
.env\Scripts\Activate.ps1
pip install -r requirements.txt
Start-Process powershell -ArgumentList "cd `"$PWD`"; .\venv\Scripts\Activate.ps1; python app.py"

Write-Host "`n=== Setting up React Admin UI ===`n"
cd "..\admin-ui"
npm install
Start-Process powershell -ArgumentList "cd `"$PWD`"; npm run dev"

Write-Host "`n✅ All services started. Flask on http://localhost:5000, React on http://localhost:5173`n"