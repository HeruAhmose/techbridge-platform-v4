
import React, { useState } from "react";

export default function ContactForm() {
  const [status, setStatus] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = e.target;
    const data = {
      name: form.name.value,
      email: form.email.value,
      message: form.message.value,
    };
    try {
      const response = await fetch("/.netlify/functions/sendEmail", {
        method: "POST",
        body: JSON.stringify(data),
      });
      const res = await response.json();
      if (res.success) setStatus("Message sent!");
      else setStatus("Error sending message.");
    } catch {
      setStatus("Server error.");
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 mt-10 bg-white rounded-xl shadow-md">
      <h2 className="text-xl font-bold font-montserrat mb-4">Contact Us</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input name="name" required placeholder="Name" className="border p-2 rounded" />
        <input name="email" type="email" required placeholder="Email" className="border p-2 rounded" />
        <textarea name="message" required placeholder="Message" rows="4" className="border p-2 rounded"></textarea>
        <button type="submit" className="bg-[#235789] text-white px-4 py-2 rounded font-bold">Send</button>
        {status && <p className="text-sm">{status}</p>}
      </form>
    </div>
  );
}
