
import React, { useEffect } from "react";
import ContactForm from "./ContactForm";

export default function LandingPage() {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "//code.tidio.co/YOUR_TIDIO_PUBLIC_KEY.js";
    script.async = true;
    document.body.appendChild(script);
  }, []);

  return (
    <div className="font-lato text-[#444B59]">
      <header className="text-center py-12 px-4 bg-[#235789] text-white">
        <h1 className="text-4xl font-bold font-montserrat">Sponsor a Future Tech Leader. Bridge a Community.</h1>
        <p className="mt-4 text-lg">Empower students. Expand digital access. Leave a legacy.</p>
        <div className="mt-6 flex justify-center gap-4 flex-wrap">
          <button className="bg-[#F45B69] text-white px-5 py-3 rounded-2xl shadow-md font-bold">Sponsor a Student</button>
          <button className="bg-white text-[#235789] px-5 py-3 rounded-2xl shadow-md font-bold">Buy Impact Tickets</button>
          <button className="bg-white text-[#235789] px-5 py-3 rounded-2xl shadow-md font-bold">Fund Tech Minutes</button>
        </div>
      </header>

      <section className="py-12 px-4 text-center">
        <h2 className="text-2xl font-bold font-montserrat mb-4">Why TechBridge Matters</h2>
        <p>Millions are left behind in the digital age. Students are hungry for real experience. TechBridge Collective connects these needs—with one bridge built by service and tech.</p>
      </section>

      <ContactForm />

      <footer className="sticky bottom-0 bg-[#235789] text-white text-center p-4 mt-12">
        <p className="font-bold">Be the Bridge.</p>
        <button className="mt-2 bg-[#F45B69] px-6 py-2 rounded-xl font-bold">Sponsor Now</button>
        <p className="mt-2 text-sm">Contact • Twitter • LinkedIn</p>
      </footer>
    </div>
  );
}
