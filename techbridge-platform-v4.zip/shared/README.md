# TechBridge Platform v4 (Shell Deploy Optimized)

## Install & Run Flask API

```sh
cd api
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Install & Run Admin UI

```sh
cd admin-ui
npm install
npm run dev
```

## Build Admin UI for Production

```sh
cd admin-ui
npm run build
```

## Deploy Notes

- Use gunicorn for production Flask server.
- Use `npm run build` and serve admin from `/admin-ui/dist`
- All .env keys from `.env.example` required.