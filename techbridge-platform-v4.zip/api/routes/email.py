from flask import Blueprint, jsonify

email_bp = Blueprint('email', __name__)

@email_bp.route('/', methods=['GET'])
def get_emails():
    return jsonify([{ "email": "test@techbridge.org" }])