from flask import Blueprint, jsonify

blog_bp = Blueprint('blog', __name__)

@blog_bp.route('/', methods=['GET'])
def get_posts():
    return jsonify([{ "id": 1, "title": "Hello", "content": "World" }])