from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")
    if email == "admin@techbridge.org" and password == "secure":
        access_token = create_access_token(identity=email, expires_delta=datetime.timedelta(hours=1))
        return jsonify(access_token=access_token)
    return jsonify({"error": "Invalid credentials"}), 401