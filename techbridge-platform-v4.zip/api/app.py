from flask import Flask
from routes.auth import auth_bp
from routes.blog import blog_bp
from routes.email import email_bp

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'your-jwt-secret'
    from flask_cors import CORS
    CORS(app)
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(blog_bp, url_prefix='/api/posts')
    app.register_blueprint(email_bp, url_prefix='/api/emails')
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000)